namespace BTCPayServer.Abstractions.Models
{
    public enum DatabaseType
    {
        Sqlite,
        Postgres,
        MySQL,
    }
}
