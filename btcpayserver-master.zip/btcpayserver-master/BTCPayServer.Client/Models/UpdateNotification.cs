namespace BTCPayServer.Client.Models
{
    public class UpdateNotification
    {
        public bool? Seen { get; set; }
    }
}
