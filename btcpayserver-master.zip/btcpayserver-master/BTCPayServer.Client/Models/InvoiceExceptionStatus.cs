namespace BTCPayServer.Client.Models;
public enum InvoiceExceptionStatus
{
    None,
    PaidLate,
    PaidPartial,
    Marked,
    Invalid,
    PaidOver
}


