namespace BTCPayServer.Client.Models
{
    public class UpdateStoreRequest : StoreBaseData
    {
    }
}
