namespace BTCPayServer.Client.Models
{
    public class CustodianAccountData : CustodianAccountBaseData
    {
        public string Id { get; set; }
    }
}
