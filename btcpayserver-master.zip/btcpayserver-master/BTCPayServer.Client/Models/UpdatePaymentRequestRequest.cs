namespace BTCPayServer.Client.Models
{
    public class UpdatePaymentRequestRequest : PaymentRequestBaseData
    {
    }
}
