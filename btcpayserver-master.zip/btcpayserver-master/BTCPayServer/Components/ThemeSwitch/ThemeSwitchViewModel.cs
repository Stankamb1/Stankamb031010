namespace BTCPayServer.Components.ThemeSwitch
{
    public class ThemeSwitchViewModel
    {
        public string CssClass { get; set; }
    }
}
